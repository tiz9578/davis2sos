# recupera il file clientraw

#!/bin/sh

set +v

anno=`/bin/date +%Y`


line=`cat clientraw.txt`

# Separa le variabili in variabili $1,$2,$3:
set -- $line	

UUID1=$(uuidgen | awk '{print $1}')
cat io_windspeed.skel	| sed -e "s/VAR001/$2/" \
	| sed -e "s/UUID/$UUID1/" \
	| sed -e "s/VAR029/${30}/" \
	| sed -e "s/VAR030/${31}/" \
	| sed -e "s/VAR031/${32}/" \
	| sed -e "s/VAR035/${36}/" \
	| sed -e "s/VAR141/$anno/" \
	| sed -e "s/VAR036/${37}/"  > io_windspeed.js	#file di output

#ATTENZIONE: il numero della variabile $ e il corrispondente valore del file clientraw.txt differiscono sempre di "1" come si vede in queste righe sopra
#le variabile del file clientraw.txt si possono leggere alla pagina: http://www.tnetweather.com/nb-0100.php#clientraw

#UUID2=$(uuidgen | awk '{print $1}')
#cat io_swindgust.skel	| sed -e "s/VAR002/$3/" \
#	| sed -e "s/UUID/$UUID2/" \
#	| sed -e "s/VAR029/${30}/" \
#	| sed -e "s/VAR030/${31}/" \
#	| sed -e "s/VAR031/${32}/" \
#	| sed -e "s/VAR035/${36}/" \
#	| sed -e "s/VAR141/$anno/" \
#	| sed -e "s/VAR036/${37}/"  > io_windgust.js	#file di output
	

	UUID3=$(uuidgen | awk '{print $1}')
cat io_winddir.skel	| sed -e "s/VAR003/$4/" \
	| sed -e "s/UUID/$UUID3/" \
	| sed -e "s/VAR029/${30}/" \
	| sed -e "s/VAR030/${31}/" \
	| sed -e "s/VAR031/${32}/" \
	| sed -e "s/VAR035/${36}/" \
	| sed -e "s/VAR141/$anno/" \
	| sed -e "s/VAR036/${37}/"  > io_winddir.js	#file di output

	UUID4=$(uuidgen | awk '{print $1}')
cat io_airtemp.skel	| sed -e "s/VAR004/$5/" \
	| sed -e "s/UUID/$UUID4/" \
	| sed -e "s/VAR029/${30}/" \
	| sed -e "s/VAR030/${31}/" \
	| sed -e "s/VAR031/${32}/" \
	| sed -e "s/VAR035/${36}/" \
	| sed -e "s/VAR141/$anno/" \
	| sed -e "s/VAR036/${37}/"  > io_airtemp.js	#file di output
	
	UUID5=$(uuidgen | awk '{print $1}')
cat io_hum.skel	| sed -e "s/VAR005/$6/" \
	| sed -e "s/UUID/$UUID5/" \
	| sed -e "s/VAR029/${30}/" \
	| sed -e "s/VAR030/${31}/" \
	| sed -e "s/VAR031/${32}/" \
	| sed -e "s/VAR035/${36}/" \
	| sed -e "s/VAR141/$anno/" \
	| sed -e "s/VAR036/${37}/"  > io_hum.js	#file di output
	
	UUID6=$(uuidgen | awk '{print $1}')
cat io_bar.skel	| sed -e "s/VAR006/$7/" \
	| sed -e "s/UUID/$UUID6/" \
	| sed -e "s/VAR029/${30}/" \
	| sed -e "s/VAR030/${31}/" \
	| sed -e "s/VAR031/${32}/" \
	| sed -e "s/VAR035/${36}/" \
	| sed -e "s/VAR141/$anno/" \
	| sed -e "s/VAR036/${37}/"  > io_bar.js	#file di output
	
	UUID7=$(uuidgen | awk '{print $1}')
cat io_dayrain.skel	| sed -e "s/VAR007/$8/" \
	| sed -e "s/UUID/$UUID7/" \
	| sed -e "s/VAR029/${30}/" \
	| sed -e "s/VAR030/${31}/" \
	| sed -e "s/VAR031/${32}/" \
	| sed -e "s/VAR035/${36}/" \
	| sed -e "s/VAR141/$anno/" \
	| sed -e "s/VAR036/${37}/"  > io_dayrain.js	#file di output
	
#	 UUID8=$(uuidgen | awk '{print $1}')
#cat io_monthrain.skel	| sed -e "s/VAR008/$9/" \
#	| sed -e "s/UUID/$UUID8/" \
#	| sed -e "s/VAR029/${30}/" \
#	| sed -e "s/VAR030/${31}/" \
#	| sed -e "s/VAR031/${32}/" \
#	| sed -e "s/VAR035/${36}/" \
#	| sed -e "s/VAR141/$anno/" \
#	| sed -e "s/VAR036/${37}/"  > io_monthrain.js	#file di output
	
#	 UUID9=$(uuidgen | awk '{print $1}')
#cat io_yearrain.skel	| sed -e "s/VAR009/${10}/" \
#	| sed -e "s/UUID/$UUID9/" \
#	| sed -e "s/VAR029/${30}/" \
#	| sed -e "s/VAR030/${31}/" \
#	| sed -e "s/VAR031/${32}/" \
#	| sed -e "s/UUID/$UUID7/" \
#	| sed -e "s/VAR141/$anno/" \
#	| sed -e "s/VAR036/${37}/"  > io_yearrain.xml	#file di output
	
	 UUID10=$(uuidgen | awk '{print $1}')
cat io_rainrate.skel	| sed -e "s/VAR010/${11}/" \
	| sed -e "s/UUID/$UUID10/" \
	| sed -e "s/VAR029/${30}/" \
	| sed -e "s/VAR030/${31}/" \
	| sed -e "s/VAR031/${32}/" \
	| sed -e "s/VAR035/${36}/" \
	| sed -e "s/VAR141/$anno/" \
	| sed -e "s/VAR036/${37}/"  > io_rainrate.js	#file di output
	
	 UUID11=$(uuidgen | awk '{print $1}')
cat io_watertemp.skel	| sed -e "s/VAR020/${21}/" \
	| sed -e "s/UUID/$UUID11/" \
	| sed -e "s/VAR029/${30}/" \
	| sed -e "s/VAR030/${31}/" \
	| sed -e "s/VAR031/${32}/" \
	| sed -e "s/VAR035/${36}/" \
	| sed -e "s/VAR141/$anno/" \
	| sed -e "s/VAR036/${37}/"  > io_watertemp.js	#file di output
	


######### UPLOAD#####################

###### configuration
LOGIN_URL=http://xxxx/account/login/
BASE_URL=http://xxxx/
USER='xxxx'
PASSWORD='xxxx'


COOKIES=cookies.txt
CURL_BIN="curl -s -c $COOKIES -b $COOKIES -e $BASE_URL"

echo -n "Authentication - get csrftoken ... \n"
$CURL_BIN $BASE_URL > /dev/null
DJANGO_TOKEN="csrfmiddlewaretoken=$(grep csrftoken $COOKIES | sed 's/^.*csrftoken\s*//')"

echo -n "Login ... \n"
$CURL_BIN \
    -d "$DJANGO_TOKEN&username=$USER&password=$PASSWORD" \
    -X POST $LOGIN_URL

echo -n "Post JSONFILE ... \n"
$CURL_BIN -XPOST -H "Content-type: application/json" \
 -d @io_windspeed.js ${BASE_URL}observations/sos/json

$CURL_BIN -XPOST -H "Content-type: application/json" \
 -d @io_winddir.js ${BASE_URL}observations/sos/json

$CURL_BIN -XPOST -H "Content-type: application/json" \
 -d @io_airtemp.js ${BASE_URL}observations/sos/json

$CURL_BIN -XPOST -H "Content-type: application/json" \
 -d @io_hum.js ${BASE_URL}observations/sos/json

$CURL_BIN -XPOST -H "Content-type: application/json" \
 -d @io_bar.js ${BASE_URL}observations/sos/json

$CURL_BIN -XPOST -H "Content-type: application/json" \
 -d @io_rainrate.js ${BASE_URL}observations/sos/json

$CURL_BIN -XPOST -H "Content-type: application/json" \
 -d @io_dayrain.js ${BASE_URL}observations/sos/json

$CURL_BIN -XPOST -H "Content-type: application/json" \
 -d @io_watertemp.js ${BASE_URL}observations/sos/json




#by tiz, esegue l'xml prodotto
#curl -m 30 -X POST -d @windspeed.xml http://david.ve.ismar.cnr.it/52nSOSv3_WAR/sos
