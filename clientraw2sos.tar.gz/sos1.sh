#!/bin/sh

#controlla : se non esiste il lockfile crealo e prosegui
lockfile="/home/meteo/lockfile"
if [ ! -e $lockfile ]; then
   trap "rm -f $lockfile; exit" INT TERM EXIT
   touch $lockfile


# controlla se esiste il file TAPPO allora continua togliendo il tappo e facendo il caricamento
#tappofile="/home/meteo/tappofile"
#	if [ -e $tappofile ]; then
   
#		rm -f $tappofile

	###   critical-section

## preleva il clientraw dalla centraline

ip=xxx.xxx.xxx.xxx

cd /home/meteo/meteoptf
wget --timeout=10 -t 3 -r -N  -nd http://$ip/B/clientraw.txt

#cp /home/meteo/ptfdata/clientraw.txt .
md5sum clientraw.txt >> /home/meteo/meteoptf/log/md5.lst
md5=$(md5sum clientraw.txt | awk '{print $1}')
echo $md5

		if [ $(grep "$md5" /home/meteo/meteoptf/log/md5.lst | wc -l) -gt 1 ]; 
		then
        		echo "Il file clientraw.txt è lo stesso di prima."

		else
        		#esegui lo script per creare le osservazioni 
       			 ./make_new_input.sh

		

			rm -f clientraw.txt
		#	rm -f /home/meteo/meteoptf/clientraw.txt
			 rm -f $lockfile
  			 trap - INT TERM EXIT

			fi
####### se non esiste il tappo rimuove il lockfile ed esci
#	else

#	trap "rm -f $lockfile; exit" INT TERM EXIT

#        fi


### se esiste il lock vuol dire che il sistema è già impegnato  in un caricamento: esci
else
   echo "mi sto già smazzano"
fi

